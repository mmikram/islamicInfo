package com.islamicinfo.bean;

/**
 * @author Dinesh Rajput
 *
 */
public class MaulanaBean {
	private Integer mId;
	private String mName;
		private String imageLink;
		public Integer getmId() {
			return mId;
		}
		public void setmId(Integer mId) {
			this.mId = mId;
		}
		public String getmName() {
			return mName;
		}
		public void setmName(String mName) {
			this.mName = mName;
		}
		public String getImageLink() {
			return imageLink;
		}
		public void setImageLink(String imageLink) {
			this.imageLink = imageLink;
		}
		
	
}
